<?php
$isi = file_get_contents("database.json");
$json = json_decode($isi, true);
$data = $json[1];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initital-scale=1">
    <title>json</title>
  </head>
  <body>
    <h1><? var_dump($data); ?></h1>
  </body>
</html>