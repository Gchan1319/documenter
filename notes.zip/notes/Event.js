function clear(elements){
    $(`#${elements}`).remove();
    $("#makeNote").css("position","absolute");
}
function inspect(query){
  $("#makeNote").css("position","fixed");
      $.getJSON('database.json',function(json){
        let anu = query;
        let note = json[anu];
        let judul = note.title;
        let update = note.LastUpdate;
        let isi = note.isi;
        let img = note.hero;
        setTimeout(()=>{
          $(".button").css("position","static");
        },1000)
        let charText = isi.length;
        $(`#${anu}`).css("opacity","1");
        $("#noteList").append(`<div class="notes" id="${anu}"><div class="card px-3 py-3"><small class="border-bottom text-muted">${update} | ${charText} Characters</small><a class="text-decoration-none"><button id="clearDiv" class="btn border-none text-dark btn-outline-light" style="z-index:1;" onclick="hapus('${anu}')">⌫</button></a><form class="mt-3 form-control formUpdate" action="update.php" method="post"><h1 class="mb-2 mt-2 bold"><b><label for="titleNote${anu}" id="buatNote${anu}"><span style="font-size:15px;">Edit</span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square mx-2 pencil" viewBox="0 0 16 16"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg></label><input class="form-control bg-light title-input" value="${judul}" readonly="true" name="titleNote" id="titleNote${anu}" type="text"></b></h1><a href="${img}"><img class="img-thumbnail mb-2 heroNote" src="${img}"/></a><textarea readonly class="notePlace bg-light form-control" name="valueUpdate">${isi}</textarea><input type="hidden" name="cekNote" value="${query}"><input type="hidden" name="imgHero" value="${img}"><button class="btn d-none mt-2 btnUpdate btn-outline-info" name="update">Update</button></form></div></div>`);
        $(`#buatNote${anu}`).on("click",function(){
        $(".title-input").removeAttr("readonly");
        $(".notePlace").removeAttr("readonly");
        $(".title-input").attr("name","titleNote");
        $(".heroNote").css("display","none");
        $(".btnUpdate").removeClass("d-none");
        })        
        setTimeout(() => {
            $(`#${anu}`).css("transform","scale(1)");
        })
        /* let lama = Math.ceil((charText*100)+5000);
        let coutdown = Math.ceil((lama/1000-3)+1);
        let x = setInterval(function(){
        let m = Math.floor(coutdown/60);
        let s = Math.floor(coutdown%60);
         $("#clearDiv").html(m+"m "+s+"s");
         coutdown--;
       },1000)
       setTimeout(function() {
           clearInterval(x);
           clear(anu);
       }, lama);*/
      })
    }
function hapus(elem){
    $(`#${elem}`).css("transform","scale(0)");
    $(`#${elem}`).css("transform","translateY(200%)");
    $(`#${elem}`).css("opacity","0");
    //$(`.notes`).addClass("d-none");
    $(".title-input").attr("readonly","true");
    $(".notePlace").attr("readonly","true");
    $(".button").css("position","fixed");
    $(".btnUpdate").addClass("d-none");
    setTimeout(() => {
      $(".heroNote").css("display","block")
    },2000)
}
function show(){
  var counter = 0;
$.getJSON("database.json",function(data){
  let database=data;
  let total = database.length;
  var x=setInterval(function(){
    if(counter==total){
      clearInterval(x);
    }else{
      counter++;
      let note=database[counter];
      let isi1 = note.isi;
      let isi=isi1.slice(0,48);
      try {
        $(`#p_${counter}`).html(isi);
      } catch (e) {
        alert(e);
      }
      $
    }
  },300)
}).catch(Error => console.log("something wrong!"))
}
show();