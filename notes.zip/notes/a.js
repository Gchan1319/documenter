$.getJSON("database.json",function(data){
    let database = data;
    let total = database.length;
    let counter = 0;
    if(total!=0){
        $("#makeNote").before(`<div class="text-center button" id="removeAll"><a href="remover.php" class="text-decoration-none"><p class="my-1 mx-2">Remove All</p></a></div>`);
    }
    var x = setInterval(function(){
      if(counter==total){
        clearInterval(x);
      }else{
      counter++;
      let note = database[counter];
      let judul = note.title;
      let update = note.LastUpdate;
      let isi1 = note.isi;
      let isi = isi1.slice(0,48);
      let img = note.hero;
      console.log(img);
      $("#noteList").append(`<div class="card card-note" onclick="inspect(${counter})"><a href="${img}"><img class="card-img-top" src="${img}" alt="${judul}"></a><div class="card-body"><h5 class="card-title">${judul}</h5><p class="card-text">${isi}..</p></div><div class="card-footer"><small class="text-muted">Last updated ${update}</small></div></div>`);
      }
      },300)
  }).catch(Error => {
    console.log("something wrong!");
    console.log(Error);
})