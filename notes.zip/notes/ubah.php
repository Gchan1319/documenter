<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Create note</title>
            <!-- bootstrap -->
    <link href="../framework/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="icon" href="../icon.jpg">
    <script src="random-hub.js" type="text/javascript" charset="utf-8"></script>
    <script src="../framework/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <style type="text/css" media="all">
        body {
            background-image: url('./bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: repeat;
        }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">
          <form id="form" class="form-control" action="../write.php" method="POST" enctype="multipart/form-data" accept-charset="utf-8">
            <input required class="form-control mb-2" type="text" name="judulNote" id="judulNote" value="" placeholder="input title" />
            <input class="form-control" type="file" name="fileToUpload" id="urlGambar" value="" placeholder="insert image here ..." required />
            <textarea required class="mb-2 form-control" name="isinote" id="isinote" rows="8" cols="40" placeholder="write your note here .."></textarea>
            <button class="btn btn-outline-primary" type="submit">Save</button>
          </form>
        </div>
      </div>
    </div>
    </script>
  </body>
</html>