<?php
$fileJson = file_get_contents("Tes.json");
$json = json_decode($fileJson,true);
foreach ($json as $value) {
  unset($json[$indexYgDiApus]);
  array_values($json);
}
$json = array_values($json);
$res = json_encode($json);
var_dump($res);
?>