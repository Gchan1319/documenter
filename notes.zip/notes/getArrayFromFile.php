<?
$file = fopen("array.json","r");
fclose($file);
$isi = file_get_contents("array.json");
$array = is_array($isi);
var_dump($isi,$array);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>example</title>
        
    </head>
    <body>
        
    </body>
</html>